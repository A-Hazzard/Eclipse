jQuery is an [OpenJS Foundation](https://openjsf.org/) project and subscribes to its code of conduct.

It is available at https://code-of-conduct.openjsf.org/.
